#include <iostream>
#include <omp.h>

using namespace std;

void bubble(int *, int);
void swap(int &, int &);
void bubble(int *a, int n)
{
    for (int i = 0; i < n; i++)
    {
        int first = i % 2;
#pragma omp parallel for shared(a, first)
        for (int j = first; j < n - 1; j += 2)
        {
            if (a[j] > a[j + 1])
            {
                swap(a[j], a[j + 1]);
            }
        }
    }
}

void swap(int &a, int &b)
{
    int test;
    test = a;
    a = b;
    b = test;
}

void mergesort(int a[], int i, int j);
void merge(int a[], int i1, int j1, int i2, int j2);
void mergesort(int a[], int i, int j)
{
    int mid;
    if (i < j)
    {
        mid = (i + j) / 2;

#pragma omp parallel sections
        {
#pragma omp section
            {
                mergesort(a, i, mid);
            }
#pragma omp section
            {
                mergesort(a, mid + 1, j);
            }
        }

        merge(a, i, mid, mid + 1, j);
    }
}

void merge(int a[], int i1, int j1, int i2, int j2)
{
    int temp[1000];
    int i, j, k;
    i = i1;
    j = i2;
    k = 0;

    while (i <= j1 && j <= j2)
    {
        if (a[i] < a[j])
        {
            temp[k++] = a[i++];
        }
        else
        {
            temp[k++] = a[j++];
        }
    }

    while (i <= j1)
    {
        temp[k++] = a[i++];
    }

    while (j <= j2)
    {
        temp[k++] = a[j++];
    }

    for (i = i1, j = 0; i <= j2; i++, j++)
    {
        a[i] = temp[j];
    }
}

int main()
{
    int choice;
    while (true)
    {
        cout << "\n1. Parallel Bubble Sort\n";
        cout << "2. Merge Sort\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1)
        {
            int *a, n;
            cout << "\nEnter total number of elements: ";
            cin >> n;
            a = new int[n];
            cout << "Enter elements: ";
            for (int i = 0; i < n; i++)
            {
                cin >> a[i];
            }

            bubble(a, n);

            cout << "\nSorted array using Parallel Bubble Sort: ";
            for (int i = 0; i < n; i++)
            {
                cout << a[i] << " ";
            }
            cout << endl;

            delete[] a;
        }
        else if (choice == 2)
        {
            int *a, n;
            cout << "\nEnter total number of elements: ";
            cin >> n;
            a = new int[n];
            cout << "Enter elements: ";
            for (int i = 0; i < n; i++)
            {
                cin >> a[i];
            }

            mergesort(a, 0, n - 1);

            cout << "\nSorted array using Merge Sort: ";
            for (int i = 0; i < n; i++)
            {
                cout << a[i] << " ";
            }
            cout << endl;

            delete[] a;
        }
        else if (choice == 3)
        {
            cout << "Exiting...";
            break;
        }
        else
        {
            cout << "Invalid choice! Please enter 1, 2, or 3." << endl;
        }
    }

    return 0;
}

