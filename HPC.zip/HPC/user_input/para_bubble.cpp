#include <iostream>
#include <vector>
#include <omp.h>

using namespace std;

// Sequential bubble sort
void bubbleSortSequential(vector<int>& array) {
    int n = array.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (array[j] > array[j + 1])
                swap(array[j], array[j + 1]);
        }
    }
}

// Parallel bubble sort
void bubbleSortParallel(vector<int>& array) {
    int n = array.size();
    #pragma omp parallel for
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (array[j] > array[j + 1])
                swap(array[j], array[j + 1]);
        }
    }
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    vector<int> arr(n);
    cout << "Enter " << n << " elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Sequential sort
    vector<int> arrSequential = arr;
    double start_time = omp_get_wtime();
    bubbleSortSequential(arrSequential);
    double end_time = omp_get_wtime();
    cout << "Sequential Bubble Sort took: " << end_time - start_time << " seconds.\n";
    cout << "Sorted array (sequential):\n";
    for (int i = 0; i < n; i++) {
        cout << arrSequential[i] << " ";
    }
    cout << endl;

    // Parallel sort
    vector<int> arrParallel = arr;
    start_time = omp_get_wtime();
    bubbleSortParallel(arrParallel);
    end_time = omp_get_wtime();
    cout << "Parallel Bubble Sort took: " << end_time - start_time << " seconds.\n";
    cout << "Sorted array (parallel):\n";
    for (int i = 0; i < n; i++) {
        cout << arrParallel[i] << " ";
    }
    cout << endl;

    return 0;
}

/*
g++ -fopenmp para_bubble.cpp -o para_bubble
./para_bubble
Enter the number of elements: 5
Enter 5 elements:
9 5 2 7 1
Sequential Bubble Sort took: 1.512e-06 seconds.
Sorted array (sequential):
1 2 5 7 9 
Parallel Bubble Sort took: 0.00314267 seconds.
Sorted array (parallel):
2 5 1 7 9
*/
