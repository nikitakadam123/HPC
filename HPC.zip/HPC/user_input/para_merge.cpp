#include <iostream>
#include <vector>
#include <omp.h>

using namespace std;

void merge(vector<int>& array, int left, int middle, int right) {
    int n1 = middle - left + 1;
    int n2 = right - middle;

    vector<int> leftArray(n1);
    vector<int> rightArray(n2);

    for (int i = 0; i < n1; ++i)
        leftArray[i] = array[left + i];
    for (int j = 0; j < n2; ++j)
        rightArray[j] = array[middle + 1 + j];

    int i = 0, j = 0, k = left;

    while (i < n1 && j < n2) {
        if (leftArray[i] <= rightArray[j]) {
            array[k] = leftArray[i];
            ++i;
        } else {
            array[k] = rightArray[j];
            ++j;
        }
        ++k;
    }

    while (i < n1) {
        array[k] = leftArray[i];
        ++i;
        ++k;
    }

    while (j < n2) {
        array[k] = rightArray[j];
        ++j;
        ++k;
    }
}

void mergeSortSequential(vector<int>& array, int left, int right) {
    if (left < right) {
        int middle = left + (right - left) / 2;

        mergeSortSequential(array, left, middle);
        mergeSortSequential(array, middle + 1, right);

        merge(array, left, middle, right);
    }
}

void mergeSortParallel(vector<int>& array, int left, int right) {
    if (left < right) {
        int middle = left + (right - left) / 2;

        #pragma omp parallel sections
        {
            #pragma omp section
            mergeSortParallel(array, left, middle);

            #pragma omp section
            mergeSortParallel(array, middle + 1, right);
        }

        merge(array, left, middle, right);
    }
}

void printArray(const vector<int>& arr) {
    for (int i = 0; i < arr.size(); ++i)
        cout << arr[i] << " ";
    cout << endl;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    vector<int> arr(n);

    cout << "Enter " << n << " elements: ";
    for (int i = 0; i < n; ++i)
        cin >> arr[i];

    vector<int> arrSequential = arr;
    vector<int> arrParallel = arr;

    double start_time, end_time;

    start_time = omp_get_wtime();
    mergeSortSequential(arrSequential, 0, n - 1);
    end_time = omp_get_wtime();

    cout << "Sequential merge sort took " << end_time - start_time << " seconds.\n";
    cout << "Sorted array (sequential): ";
    printArray(arrSequential);

    start_time = omp_get_wtime();
    mergeSortParallel(arrParallel, 0, n - 1);
    end_time = omp_get_wtime();

    cout << "Parallel merge sort took " << end_time - start_time << " seconds.\n";
    cout << "Sorted array (parallel): ";
    printArray(arrParallel);

    return 0;
}

/*
g++ -fopenmp para_merge.cpp -o para_merge
./para_merge
Enter the number of elements: 10
Enter 10 elements: 5 9 2 7 1 6 3 8 4 10    
Sequential merge sort took 2.8432e-05 seconds.
Sorted array (sequential): 1 2 3 4 5 6 7 8 9 10 
Parallel merge sort took 0.0135242 seconds.
Sorted array (parallel): 1 2 3 4 5 6 7 8 9 10 
*/
