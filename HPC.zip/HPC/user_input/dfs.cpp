#include <iostream>
#include <vector>
#include <chrono>
#include <omp.h> // Include OpenMP library
using namespace std;
using namespace std::chrono;

class Graph {
    int V;  
    vector<vector<int>> adj;  

public:
    Graph(int V) : V(V), adj(V) {}

    void addEdge(int v, int w) {
        adj[v].push_back(w);
        adj[w].push_back(v); // for undirected graph
    }

    void sequentialDFS(int startVertex) {
        vector<bool> visited(V, false);
        sequentialDFSUtil(startVertex, visited);
    }

    void sequentialDFSUtil(int v, vector<bool>& visited) {
        visited[v] = true;
        cout << v << " ";

        for (int i = 0; i < adj[v].size(); ++i) {
            int n = adj[v][i];
            if (!visited[n])
                sequentialDFSUtil(n, visited);
        }
    }

    void parallelDFS(int startVertex) {
        vector<bool> visited(V, false);
        #pragma omp parallel
        #pragma omp single nowait
        parallelDFSUtil(startVertex, visited);
    }

    void parallelDFSUtil(int v, vector<bool>& visited) {
        visited[v] = true;
        cout << v << " ";

        #pragma omp parallel for
        for (int i = 0; i < adj[v].size(); ++i) {
            int n = adj[v][i];
            if (!visited[n])
                parallelDFSUtil(n, visited);
        }
    }
};

int main() {
    int num_nodes, num_edges;
    cout << "Enter the number of nodes: ";
    cin >> num_nodes;
    cout << "Enter the number of edges: ";
    cin >> num_edges;

    Graph g(num_nodes);
    cout << "Enter the edges (node1 node2):" << endl;
    for (int i = 0; i < num_edges; ++i) {
        int node1, node2;
        cin >> node1 >> node2;
        g.addEdge(node1, node2);
    }

    int start_node;
    cout << "Enter the starting node: ";
    cin >> start_node;

    // Sequential DFS
    auto seq_start = high_resolution_clock::now();
    cout << "Depth-First Search (DFS) - Sequential: ";
    g.sequentialDFS(start_node);
    cout << endl;
    auto seq_end = high_resolution_clock::now();
    auto seq_duration = duration_cast<milliseconds>(seq_end - seq_start);

    // Parallel DFS
    auto par_start = high_resolution_clock::now();
    cout << "Depth-First Search (DFS) - Parallel: ";
    g.parallelDFS(start_node);
    cout << endl;
    auto par_end = high_resolution_clock::now();
    auto par_duration = duration_cast<milliseconds>(par_end - par_start);

    // Output duration
    cout << "Duration time (Sequential): " << seq_duration.count() << " milliseconds" << endl;
    cout << "Duration time (Parallel): " << par_duration.count() << " milliseconds" << endl;

    return 0;
}

/*
g++ -fopenmp dfs.cpp -o dfs
./dfs
Enter the number of nodes: 7
Enter the number of edges: 6
Enter the edges (node1 node2):
0 1
0 2
1 3
1 4
2 5
2 6
Enter the starting node: 0
Depth-First Search (DFS) - Sequential: 0 1 3 4 2 5 6 
Depth-First Search (DFS) - Parallel: 0 1 3 4 2 5 6 
Duration time (Sequential): 0 milliseconds
Duration time (Parallel): 11 milliseconds

*/
