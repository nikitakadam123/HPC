#include <iostream>
#include <vector>
#include <queue>
#include <chrono>
#include <omp.h> // Include OpenMP library
using namespace std;
using namespace std::chrono;

vector<int> sequential_bfs(vector<vector<int>>& graph, int start) {
    vector<bool> visited(graph.size(), false);
    queue<int> q;
    vector<int> traversal;

    visited[start] = true;
    q.push(start);

    while (!q.empty()) {
        int current = q.front();
        q.pop();
        traversal.push_back(current);

        for (int neighbor : graph[current]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }
    }

    return traversal;
}

vector<int> parallel_bfs(vector<vector<int>>& graph, int start) {
    vector<bool> visited(graph.size(), false);
    queue<int> q;
    vector<int> traversal;

    visited[start] = true;
    q.push(start);

    while (!q.empty()) {
        int q_size = q.size();
        vector<int> local_traversal;
        #pragma omp parallel
        {
            vector<int> private_traversal;
            #pragma omp for
            for (int i = 0; i < q_size; ++i) {
                int current;
                #pragma omp critical
                {
                    current = q.front();
                    q.pop();
                }
                private_traversal.push_back(current);

                for (int neighbor : graph[current]) {
                    #pragma omp critical
                    {
                        if (!visited[neighbor]) {
                            visited[neighbor] = true;
                            q.push(neighbor);
                        }
                    }
                }
            }
            #pragma omp critical
            {
                traversal.insert(traversal.end(), private_traversal.begin(), private_traversal.end());
            }
        }
    }

    return traversal;
}

int main() {
    int num_nodes, num_edges;
    cout << "Enter the number of nodes: ";
    cin >> num_nodes;
    cout << "Enter the number of edges: ";
    cin >> num_edges;

    vector<vector<int>> graph(num_nodes);
    cout << "Enter the edges (node1 node2):" << endl;
    for (int i = 0; i < num_edges; ++i) {
        int node1, node2;
        cin >> node1 >> node2;
        graph[node1].push_back(node2);
        graph[node2].push_back(node1); // Assuming an undirected graph
    }

    int start_node;
    cout << "Enter the starting node: ";
    cin >> start_node;

    // Sequential BFS
    auto seq_start = high_resolution_clock::now();
    vector<int> seq_traversal = sequential_bfs(graph, start_node);
    auto seq_end = high_resolution_clock::now();
    auto seq_duration = duration_cast<milliseconds>(seq_end - seq_start);

    // Parallel BFS
    auto par_start = high_resolution_clock::now();
    vector<int> par_traversal = parallel_bfs(graph, start_node);
    auto par_end = high_resolution_clock::now();
    auto par_duration = duration_cast<milliseconds>(par_end - par_start);

    // Output results
    cout << "Sequential BFS Traversal: ";
    for (int node : seq_traversal) {
        cout << node << " ";
    }
    cout << endl;
    cout << "Sequential BFS Time: " << seq_duration.count() << " milliseconds" << endl;

    cout << "Parallel BFS Traversal: ";
    for (int node : par_traversal) {
        cout << node << " ";
    }
    cout << endl;
    cout << "Parallel BFS Time: " << par_duration.count() << " milliseconds" << endl;

    return 0;
}

/*
g++ -fopenmp dfs.cpp -o bfs
./bfs
Enter the number of nodes: 6
Enter the number of edges: 6
Enter the edges (node1 node2):
0 1
0 2
1 3
1 4
2 5
3 4
Enter the starting node: 0

*/
